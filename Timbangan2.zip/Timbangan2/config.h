#ifndef CONFIG_H
#define CONFIG_H

// ================= WIFI =================
#define WIFI_SSID "Aaa"
#define WIFI_PASS "12345678910"

// Gunakan domain backend yang bisa dijangkau ESP32.
#define API_BASE_URL "https://api-entok.bengkelit.id/api"
#define DEVICE_API_KEY "entok-2026"
#define TIMBANGAN_ID 2

// ================= LCD I2C =================
#define LCD_ADDR 0x27
#define LCD_COLS 16
#define LCD_ROWS 2
#define LCD_SDA 21
#define LCD_SCL 22

// ================= HX711 =================
#define LOADCELL_DOUT_PIN 16
#define LOADCELL_SCK_PIN 17
#define CALIBRATION_FACTOR -21148.876141137612
#define ZERO_THRESHOLD 0.030

// ================= KEYPAD =================
#define ROW1_PIN 32
#define ROW2_PIN 33
#define ROW3_PIN 25
#define ROW4_PIN 26

#define COL1_PIN 27
#define COL2_PIN 14
#define COL3_PIN 12
#define COL4_PIN 13

#define MAX_ITEMS 40

#endif
